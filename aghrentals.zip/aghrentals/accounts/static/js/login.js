const username = document.getElementById("id_username");
const password = document.getElementById("id_password");

username.placeholder = "Enter Your Username";
password.placeholder = "Enter Password";
