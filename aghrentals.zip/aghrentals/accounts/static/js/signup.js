const firstName = document.getElementById("id_firstName");
const lastName = document.getElementById("id_lastName");
const email = document.getElementById("id_email");
const username = document.getElementById("id_username");
const password1 = document.getElementById("id_password1");
const password2 = document.getElementById("id_password2");

firstName.placeholder = "Enter First Name";
lastName.placeholder = "Enter Last Name";
email.placeholder = "Enter Your Email Address";
username.placeholder = "Enter Your Username";
password1.placeholder = "Enter Password";
password2.placeholder = "Re-enter Password";
